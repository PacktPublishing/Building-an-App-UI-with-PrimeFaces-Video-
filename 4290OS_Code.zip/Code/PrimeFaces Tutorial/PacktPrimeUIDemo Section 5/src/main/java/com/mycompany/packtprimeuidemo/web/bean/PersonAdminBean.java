/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.packtprimeuidemo.web.bean;

import com.mycompany.packtprimeuidemo.model.Person;
import com.mycompany.packtprimeuidemo.service.PersonService;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import static org.springframework.web.util.TagUtils.SCOPE_SESSION;

@Scope(SCOPE_SESSION)
@Controller
public class PersonAdminBean implements java.io.Serializable {

    @Resource
    private PersonService personService;
    private String firstname;
    private String surname;
    private Person selectedPerson;

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Person findById(String id) {
        return personService.findById(id);
    }

    public void save(Person person) {
        personService.save(person);
    }

    public List<Person> findAll() {
        return personService.findAll();
    }

    public String addPerson() {
        Person person = new Person();
        person.setFirstname(firstname);
        person.setSurname(surname);
        save(person);
        return "index.jsf?faces-redirect=true";
    }

    public String editPerson() {
        selectedPerson.setFirstname(firstname);
        selectedPerson.setSurname(surname);
        save(selectedPerson);
        return "index.jsf?faces-redirect=true";
    }

    public String deletePerson() {
        personService.delete(selectedPerson);
        return "index.jsf?faces-redirect=true";
    }

    public String displayAddPerson() {
        firstname = "";
        surname = "";
        return "addPerson.jsf?faces-redirect=true";
    }

    private void populateScreen(Person person) {
        firstname = person.getFirstname();
        surname = person.getSurname();
    }

    public String displayEditPerson(Person person) {
        selectedPerson = person;
        populateScreen(person);
        return "editPerson.jsf?faces-redirect=true";
    }

    public String displayDeletePerson(Person person) {
        selectedPerson = person;
        populateScreen(person);
        return "deletePerson.jsf?faces-redirect=true";
    }
}
