/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.packtprimeuidemo.web.bean;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import static org.springframework.web.util.TagUtils.SCOPE_REQUEST;

@Scope(SCOPE_REQUEST)
@Controller
public class PersonSearchBean implements java.io.Serializable {

    public void test() {
        System.out.println("test");
    }
}
